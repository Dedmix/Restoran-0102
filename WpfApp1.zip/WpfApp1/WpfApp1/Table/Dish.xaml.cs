﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1.Table
{
    /// <summary>
    /// Логика взаимодействия для Dish.xaml
    /// </summary>
    public partial class Dish : Page
    {
        public Dish()
        {
            InitializeComponent();
        }

        private void B1_Click(object sender, RoutedEventArgs e)
        {
            bd.FastFoodEntities connection = new bd.FastFoodEntities();
            string Name = TB1.Text;
            string Price = TB2.Text;
            bd.Dish dish = new bd.Dish();
            dish.Name = Name;
            dish.Price = Convert.ToDecimal(Price);
            if (Name !="" && Price !="")
            {
                connection.Dish.Add(dish);
                connection.SaveChanges();
                MessageBox.Show("Блюдо успешно добавлен");
            }
            else {MessageBox.Show("Ошибка: Проверте заполнение формы Названиее и Цена "); }

        }
    }
}

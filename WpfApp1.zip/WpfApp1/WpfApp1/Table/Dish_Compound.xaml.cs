﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1.Table
{
    /// <summary>
    /// Логика взаимодействия для Dish_Compound.xaml
    /// </summary>
    public partial class Dish_Compound : Page
    {
        public Dish_Compound()
        {
            InitializeComponent();
            DishList();
            IngridientList();
        }

        private void DishList()
        {
            bd.FastFoodEntities connection = new bd.FastFoodEntities();

            var dish = connection.Dish.ToList();
            foreach (var Dish in dish)
            {
                CB1.Items.Add(Dish.Name);
            }

        }


        private void IngridientList()
        {
            bd.FastFoodEntities connection = new bd.FastFoodEntities();

            var ingridient = connection.Ingredient.ToList();
            foreach (var Ingridient in ingridient)
            {
                CB2.Items.Add(Ingridient.Name);
            }
        }

        private void B1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void B3_Click(object sender, RoutedEventArgs e)
        {
            LB1.Items.Clear();
            bd.FastFoodEntities connection = new bd.FastFoodEntities();
            var Recipe = connection.DishCompound.ToList();
            string Dish = CB1.Text;
            foreach (var Dishes_ingridient in Recipe)
            {
                if (Dish == Dishes_ingridient.Dish1.Name)
                {
                    LB1.Items.Add(Dishes_ingridient.Ingredient1.Name);
                }
            }
        }

        private void LB1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            LB1.Items.Clear();
        }

        private void B2_Click(object sender, RoutedEventArgs e)
        {
            bd.FastFoodEntities connection = new bd.FastFoodEntities();
            string ingridient = CB2.Text;
            bool FandIngredient = false;
            foreach (var Ingridients in CB2.Items)
            {
                if (Ingridients == ingridient)
                {
                    MessageBox.Show("Этот ингридиент уже существует!");
                    break;
                }
                else
                {
                    LB1.Items.Remove(CB2.Text);
                    LB1.Items.Add(CB2.Text);
                    FandIngredient = true;
                }
                if (FandIngredient)
                {
                    break;
                }
            }
        }

        private void B4_Click(object sender, RoutedEventArgs e)
        {
            LB1.Items.Remove(CB2.Text);
        }
    }

    
}

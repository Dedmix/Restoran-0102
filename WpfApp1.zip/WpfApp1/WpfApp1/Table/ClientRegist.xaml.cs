﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1.Table
{
    /// <summary>
    /// Логика взаимодействия для ClientRegist.xaml
    /// </summary>
    public partial class ClientRegist : Page
    {
        public ClientRegist()
        {
            InitializeComponent();
            
        }

        private void B1_Click(object sender, RoutedEventArgs e)
        {
            bd.FastFoodEntities connection = new bd.FastFoodEntities();
            string Phone = TB1.Text;
            string Name = TB2.Text;
            string Address = TB3.Text;
            bd.Client ClientRegist = new bd.Client();
            ClientRegist.Phone = Phone;
            ClientRegist.FullName = Name;
            ClientRegist.Address = Address;

            if (Phone != "" && Name != "" && Address != "")
            {
                connection.Client.Add(ClientRegist);
                connection.SaveChanges();
                MessageBox.Show("Клиент успешно добавлен");
            }
            else { MessageBox.Show("Ошибка: Проверте заполнение формы Телефон, ФИО и Адрес"); }
        }   
    }
}

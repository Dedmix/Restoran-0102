﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Table
{
    class Class1
    {
        public static Authorization authorization = new Authorization();
        public static Order Order = new Order();
        public static EmployeeRegist employeeregist = new EmployeeRegist();
        public static ListEmployee listEmployee = new ListEmployee();
        public static ClientRegist clientRegist = new ClientRegist();
        public static Ingredint ingredint = new Ingredint();
        public static Dish dish = new Dish();
        public static Dish_Compound Dish_Compound = new Dish_Compound();
        
        
    }
}

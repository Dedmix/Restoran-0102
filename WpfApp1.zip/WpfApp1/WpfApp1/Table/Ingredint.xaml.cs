﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1.Table
{
    /// <summary>
    /// Логика взаимодействия для Ingredint.xaml
    /// </summary>
    public partial class Ingredint : Page
    {
        public Ingredint()
        {
            InitializeComponent();
            bd.FastFoodEntities connection = new bd.FastFoodEntities();
            var List = connection.Unit.ToList();
            foreach (var Empl in List)
            {
                CB1.Items.Add(Empl.Unit1);
            }
        }

        private void B1_Click(object sender, RoutedEventArgs e)
        {
            bd.FastFoodEntities connection = new bd.FastFoodEntities();
            
            string Name = TB2.Text;
            string Unit = CB1.Text;
            bd.Ingredient ingredient = new bd.Ingredient();
            ingredient.Name = Name;
            ingredient.Unit = Unit;

            if (Name != "" && Unit != "")
            {
                connection.Ingredient.Add(ingredient);
                connection.SaveChanges();
                MessageBox.Show("Ингредиент успешно добавлен");
            }
            else { MessageBox.Show("Ошибка: Проверте заполнение формы Наименование и Измерение"); }
        }

        private void CB1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}

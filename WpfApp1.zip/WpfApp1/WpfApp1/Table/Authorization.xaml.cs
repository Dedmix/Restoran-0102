﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1.Table
{
    /// <summary>
    /// Логика взаимодействия для Authorization.xaml
    /// </summary>
    public partial class Authorization : Page
    {
        public Authorization()
        {
            InitializeComponent();
        }

        private void B1_Click(object sender, RoutedEventArgs e)
        {
            bd.FastFoodEntities connection = new bd.FastFoodEntities();
            string UserLogin = TB1.Text;
            string Password = TB2.Text;
            var List = connection.Employee.ToList();

            if (UserLogin != "" && Password != "")
            {
                foreach (var Emplotes in List)
                    if (Emplotes.Phone == UserLogin && Emplotes.Password == Password)
                    {
                        MessageBox.Show("Добро пожвловать на работу");
                        NavigationService.Navigate(Table.Class1.Order);
                    }
            }
            else { MessageBox.Show("Ведите логин и пароль"); }

        }
    }
}
    

